// Node.js proxy: fetch Krynet.ai and strip frame-blocking headers
const express = require("express");
const fetch = require("node-fetch");
const app = express();

app.get("/", async (req, res) => {
  try {
    const response = await fetch("https://krynet.ai");
    let html = await response.text();

    // Optional: remove frame-blocking CSP meta tags
    html = html.replace(/<meta http-equiv="Content-Security-Policy".*?>/gi, "");
    html = html.replace(/<meta http-equiv="X-Frame-Options".*?>/gi, "");

    res.send(html);
  } catch (err) {
    res.status(500).send("Error loading Krynet.ai: " + err.message);
  }
});

app.listen(8080, () => {
  console.log("Local Krynet proxy running at http://127.0.0.1:8080");
});