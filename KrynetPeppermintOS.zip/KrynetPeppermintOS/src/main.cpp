#include "sciter-x.h"
#include "sciter-x-window.hpp"
#include <functional>

int uimain(std::function<int()> run) {
    // Create main window
    sciter::window mainWindow(sciter::window::root, sciter::SIZE{1024,768});

    // Disable host check / web security for full proxy access
    mainWindow.set_options(SW_ALLOW_FILE_IO | SW_DISABLE_HOST_CHECK);

    // Load UI
    mainWindow.load_file(L"app.html");
    mainWindow.expand();

    return run();
}