import UIKit
import WebKit

class WebViewController: UIViewController, WKNavigationDelegate {

    private var webView: WKWebView!

    override func loadView() {
        // WebView configuration
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        // JS injection: set a flag for in-app behavior
        let script = """
        window.isKrynetApp = true;
        console.log("Krynet iOS Unofficial Client Loaded");
        """
        let userScript = WKUserScript(
            source: script,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: false
        )
        config.userContentController.addUserScript(userScript)

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self

        // Native feel tweaks
        webView.scrollView.bounces = false
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        view = webView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        loadKrynet()
    }

    override var prefersStatusBarHidden: Bool { true }

    private func loadKrynet() {
        guard let url = URL(string: "https://krynet.ai/web") else { return }
        let request = URLRequest(url: url)
        webView.load(request)
    }

    // Open external links in Safari
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {

        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }

        if url.host != "krynet.ai" {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }

        decisionHandler(.allow)
    }
}